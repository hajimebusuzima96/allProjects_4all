import React, { Component } from 'react';
import './Navbar.css';

class Navbar extends Component {
    render(){
        return(
            <div className="navbar">
                Navbar
            </div>
        )
    }
}

export default Navbar;