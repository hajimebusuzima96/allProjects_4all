import Popper  from 'popper.js'

window.Popper = Popper