<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">	
	<title>Mestre Detalhe</title>
	<link href="http://<?php echo APP_HOST; ?>/public/css/bootstrap.min.css" rel="stylesheet">
	<link href="http://<?php echo APP_HOST; ?>/public/font-awesome/css/font-awesome.css" rel="stylesheet" />  	
	<link href="http://<?php echo APP_HOST; ?>/public/css/style.css" rel="stylesheet">
	<link href="http://<?php echo APP_HOST; ?>/public/css/style-responsive.css" rel="stylesheet" />	
	<link rel="stylesheet" href="http://<?php echo APP_HOST; ?>/public/css/easy-autocomplete.min.css"> 	
	<link rel="stylesheet" href="http://<?php echo APP_HOST; ?>/public/css/easy-autocomplete.themes.min.css"> 
</head>
<body>
	<section id="container" class="">