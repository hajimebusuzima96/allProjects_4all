<section id="main-content">
  <section class="wrapper">
    <div class="row">      
      <div class="col-lg-12">
        <section class="pane panel-default">
          <header class="panel-heading">
            Aplicação Mestre-detalhe com PHP e MVC
          </header>          
        </section>
      </div>
    </div>
  </section>
</section>