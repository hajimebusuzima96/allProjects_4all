<section id="main-content">
	<section class="wrapper">
		<div class="row">      
			<div class="col-lg-12">
				<section class="pane panel-default">
					<header class="panel-heading">
						Erro <?php echo $errorCode; ?>
					</header>
					<div class="panel-body">  
						<?php echo $errorMessage; ?>            
					</div>
				</section>
			</div>
		</div>
	</section>
</section>

