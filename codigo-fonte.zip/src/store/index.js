import { createStore, applyMiddleware } from 'redux'
import reducers from './reducers'
import thunk from 'redux-thunk'

export * from './actions'
export default createStore(
  reducers,
  applyMiddleware(thunk)
)
