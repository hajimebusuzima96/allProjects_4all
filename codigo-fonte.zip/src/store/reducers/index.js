import { combineReducers } from 'redux'
import pacote from './pacote'

export default combineReducers({ pacote })
