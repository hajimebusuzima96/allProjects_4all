import './CardPacote.css'
export { default } from './CardPacote'
