import React, { Component } from 'react'

export default class Footer extends Component {
  render () {
    return (
      <div className='footer'>
        <div>
          <p>© 2018 - Todos os direitos reservados</p>
        </div>
      </div>
    )
  }
}
