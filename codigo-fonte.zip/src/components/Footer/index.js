import './Footer.css'
export { default } from './Footer'
