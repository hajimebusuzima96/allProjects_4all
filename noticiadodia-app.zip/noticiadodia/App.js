import React from 'react';
import TelaInicial from './componentes/TelaInicial';

export default function App() {
  return (
    <TelaInicial />
  )
}
