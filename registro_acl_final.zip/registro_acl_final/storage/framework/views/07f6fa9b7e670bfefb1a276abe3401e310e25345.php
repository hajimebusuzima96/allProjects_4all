<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
   <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php echo e($error); ?><br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endif; ?>
<div class="panel panel-default">

<div class="panel-heading"><h3>Cadastre-se</h3></div>
<div class="panel-body">
<form class="form-horizontal" method="post" action="<?php echo e(route ('salvar')); ?>">
<?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label for="nome" class="col-sm-2 control-label">Nome</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="nome" placeholder="Digite seu nome">
    </div>
  </div>
  <div class="form-group">
    <label for="email" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="email" class="form-control" name="email" placeholder="Digite seu email">
    </div>
  </div>
  <hr>
  <div class="form-group">
    <label for="login" class="col-sm-2 control-label">Login</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="login" placeholder="Digite seu login">
    </div>
  </div>
  <div class="form-group">
    <label for="senha" class="col-sm-2 control-label">Senha</label>
    <div class="col-sm-10">
      <input type="password" class="form-control" name="senha" placeholder="Digite seu senha">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
        <button type="reset" class="btn btn-default">Cancelar</button>
        <button type="submit" class="btn btn-primary">Registrar</button>
    </div>
  </div>
</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>