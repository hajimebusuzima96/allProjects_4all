<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">    
        <div class="panel-heading">Lista de Usuários</div>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>Login</th>
                            <th>Cargo</th>
                            <th>Ações</th>
                        </tr>
                    </thead>            
                    <tbody>            
                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($usuario->nome); ?></td>
                                <td><?php echo e($usuario->email); ?></td>
                                <td><?php echo e($usuario->login); ?></td>
                                <td><?php echo e($usuario->cargo); ?></td>
                                <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', App\Usuario::class)): ?>
                                    <a href="<?php echo e(route('editar', $usuario->id)); ?>"><i class="glyphicon glyphicon-pencil"></i></a>
                                <?php endif; ?>
                                </td>                                
                            </tr>                         
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                 
                    </tbody>
                </table> 
            </div> 
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>