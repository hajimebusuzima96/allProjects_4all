-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: documentacaosql
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `documentacaosql`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `documentacaosql` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `documentacaosql`;

--
-- Table structure for table `ferias`
--

DROP TABLE IF EXISTS `ferias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ferias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(11) NOT NULL,
  `data_inicio` date DEFAULT NULL,
  `data_fim` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ferias`
--

LOCK TABLES `ferias` WRITE;
/*!40000 ALTER TABLE `ferias` DISABLE KEYS */;
INSERT INTO `ferias` VALUES (1,1,'2018-01-08','2018-01-22'),(2,4,'2018-02-05','2018-02-15'),(3,7,'2017-05-08','2017-05-22'),(4,5,'2017-09-11','2017-09-25'),(5,12,'2018-01-08','2018-01-21');
/*!40000 ALTER TABLE `ferias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `funcionario`
--

DROP TABLE IF EXISTS `funcionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `funcionario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `salario` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `funcionario`
--

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` VALUES (1,'Nicolas Silva','3500'),(2,'Pedro Henrique','2500'),(3,'Manuel Soares','3500'),(4,'Lucas Bené','1350'),(5,'Thiago Enrique','3745'),(9,'Luana Dias','2900'),(10,'Bruno da Silva','2400'),(11,'Osvaldo Mont ','1980'),(12,'Deleon Campolina','2200');
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes`
--

DROP TABLE IF EXISTS `likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `likes` (
  `id_like` int(11) NOT NULL AUTO_INCREMENT,
  `id_topico` int(11) NOT NULL,
  `data_criacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_like`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes`
--

LOCK TABLES `likes` WRITE;
/*!40000 ALTER TABLE `likes` DISABLE KEYS */;
INSERT INTO `likes` VALUES (1,1,'2016-07-17 12:41:40',1234),(2,1,'2016-07-17 12:41:40',432),(3,1,'2016-08-19 12:41:40',654),(4,3,'2016-08-22 12:41:40',5688),(5,3,'2017-08-24 12:41:40',87),(6,3,'2017-12-18 12:41:40',5443),(7,3,'2018-01-21 12:41:40',654),(8,3,'2018-04-22 12:41:40',432),(9,2,'2018-07-17 12:41:40',5643),(10,2,'2018-08-16 12:41:40',5456);
/*!40000 ALTER TABLE `likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topico`
--

DROP TABLE IF EXISTS `topico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topico` (
  `id_topico` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `data_cadastro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_topico`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topico`
--

LOCK TABLES `topico` WRITE;
/*!40000 ALTER TABLE `topico` DISABLE KEYS */;
INSERT INTO `topico` VALUES (1,'Como utilizar JOINs com três tabelas','2016-04-18 12:39:10'),(2,'Por que a minha query não funciona no MySQL?','2016-04-20 12:39:10'),(3,'Erro ao conectar com o Firebird','2016-07-04 12:39:10'),(4,'Usando TOP no POSTGRES','2016-07-23 12:39:10'),(5,'Consulta não gera os resultados como experado','2016-10-17 12:39:10'),(6,'Listar apenas os dados duplicados no banco de dados','2016-10-18 12:39:10');
/*!40000 ALTER TABLE `topico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoria_produto`
--

DROP TABLE IF EXISTS `categoria_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria_produto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_produto`
--

LOCK TABLES `categoria_produto` WRITE;
/*!40000 ALTER TABLE `categoria_produto` DISABLE KEYS */;
INSERT INTO `categoria_produto` VALUES (1,'infantil'),(2,'Informatica'),(3,'Educacional');
/*!40000 ALTER TABLE `categoria_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comentario`
--

DROP TABLE IF EXISTS `comentario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comentario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comentario` text,
  `data` date DEFAULT NULL,
  `id_projeto` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comentario_projetos_idx` (`id_projeto`),
  KEY `fk_comentario_usuario1_idx` (`id_usuario`),
  CONSTRAINT `fk_comentario_projetos` FOREIGN KEY (`id_projeto`) REFERENCES `projetos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_comentario_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comentario`
--

LOCK TABLES `comentario` WRITE;
/*!40000 ALTER TABLE `comentario` DISABLE KEYS */;
INSERT INTO `comentario` VALUES (1,'Muito legal essa aplicação! Adorei usar o React','2018-04-10',7,1),(2,'React é muito simples! Curti o projeto! parabéns!','2018-05-10',7,3),(3,'Muito top!','2018-05-20',9,1),(4,'Parabéns aos envolvidos!','2018-05-20',9,2),(5,'Muito legal, sempre gostei do Laravel.','2018-05-20',9,3),(6,'Interessante a forma de recueprar as informações. Não sabia. Gostei!','2018-05-21',9,4),(7,'Consigo fazer o mesmo com CodeIgniter?','2018-05-22',9,5),(8,'React é apenas JavaScript, há uma API bem pequena para aprender, apenas algumas funções e como usá-las. Depois disso, suas habilidades em JavaScript serão o que te farão um melhor desenvolvedor React','2018-05-23',7,6);
/*!40000 ALTER TABLE `comentario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes_por_comentario`
--

DROP TABLE IF EXISTS `likes_por_comentario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `likes_por_comentario` (
  `id_usuario` int(11) NOT NULL,
  `id_comentario` int(11) NOT NULL,
  KEY `fk_likes_por_comentario_usuario1_idx` (`id_usuario`),
  KEY `fk_likes_por_comentario_comentario1_idx` (`id_comentario`),
  CONSTRAINT `fk_likes_por_comentario_comentario1` FOREIGN KEY (`id_comentario`) REFERENCES `comentario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_likes_por_comentario_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes_por_comentario`
--

LOCK TABLES `likes_por_comentario` WRITE;
/*!40000 ALTER TABLE `likes_por_comentario` DISABLE KEYS */;
INSERT INTO `likes_por_comentario` VALUES (5,8),(1,8),(2,8),(4,8);
/*!40000 ALTER TABLE `likes_por_comentario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `likes_por_projeto`
--

DROP TABLE IF EXISTS `likes_por_projeto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `likes_por_projeto` (
  `id_projeto` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  KEY `fk_likes_por_projeto_projetos1_idx` (`id_projeto`),
  KEY `fk_likes_por_projeto_usuario1_idx` (`id_usuario`),
  CONSTRAINT `fk_likes_por_projeto_projetos1` FOREIGN KEY (`id_projeto`) REFERENCES `projetos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_likes_por_projeto_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `likes_por_projeto`
--

LOCK TABLES `likes_por_projeto` WRITE;
/*!40000 ALTER TABLE `likes_por_projeto` DISABLE KEYS */;
INSERT INTO `likes_por_projeto` VALUES (7,1),(7,3),(7,4),(7,5),(7,10),(10,1),(10,2),(10,3),(8,1),(8,2),(8,3),(8,4),(8,5),(8,6),(9,1),(9,2),(9,3),(9,4),(9,5),(9,6),(9,7),(9,8),(9,9),(9,10),(7,6);
/*!40000 ALTER TABLE `likes_por_projeto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produto`
--

DROP TABLE IF EXISTS `produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `produto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `preco` decimal(10,2) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produto`
--

LOCK TABLES `produto` WRITE;
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` VALUES (1,'Bola',35.00,1),(2,'Patinete',120.00,1),(3,'Carrinho',15.00,1),(4,'Skate',296.00,1),(5,'Notebook',3500.00,2),(6,'Monitor LG 19',450.00,2),(7,'O Diário de Anne Frank',45.00,3),(8,'O dia do Curinga',65.00,3),(9,'O mundo de Sofia',48.00,3),(10,'Através do Espelho',38.00,3),(12,'Bicicleta Mormai',1350.00,2);
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projetos`
--

DROP TABLE IF EXISTS `projetos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projetos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projetos`
--

LOCK TABLES `projetos` WRITE;
/*!40000 ALTER TABLE `projetos` DISABLE KEYS */;
INSERT INTO `projetos` VALUES (7,'Criando uma aplicação com React','2018-04-10','https://www.devmedia.com.br/exemplo/api-rest-react-mobile-aplicacao-completa-gotour/78'),(8,'API RestFUL com Lumen','2018-05-10','https://www.devmedia.com.br/exemplo/criando-uma-api-restful-com-lumen/71'),(9,'Consumindo uma API RestFUL com Laravel','2018-05-20','https://www.devmedia.com.br/exemplo/projeto-gotour-cliente-web-para-a-api-de-moderacao-de-uma-agencia-de-turismo/72'),(10,'Documentação SQL','2018-05-21','https://www.devmedia.com.br/exemplo/documentacao-sql/76');
/*!40000 ALTER TABLE `projetos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'Pablo Matheus Ribeiro de Carvalho','pablo@mvpdevup.com.br','1234'),(2,'Samuel Herbas','samuelherbascarvalho@gmail.com','taty'),(3,'Lucas Gabriel','lucasgb@yahoo.com.br','kjiu89'),(4,'Pedro Miguel','pdmiguel89@gmail.com','pd_mmi3'),(5,'Eryka Dias','erykajl@hotmail.com','wdofwct'),(6,'Ricardo Tavares','rcadt@hotmail.com','99imo'),(7,'Luana da Silva','luanasilvada@hotmail.com','lulu98'),(8,'Fátima Bernardes','fafa@globo.com','fafabon'),(9,'Raquel Faria','raquel_faria@uol.com.br','raqllar'),(10,'Diego Souza','chameco@mvpdevup.com.br','gerentechameco'),(11,'Fernando Souza','fernandobarriga@gmail.com','123soueu');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venda_produto`
--

DROP TABLE IF EXISTS `venda_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `venda_produto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_produto` int(11) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venda_produto`
--

LOCK TABLES `venda_produto` WRITE;
/*!40000 ALTER TABLE `venda_produto` DISABLE KEYS */;
INSERT INTO `venda_produto` VALUES (1,1,'2018-05-15',35.00),(2,1,'2018-06-15',35.00),(3,1,'2018-07-15',35.00),(4,2,'2018-07-15',120.00),(5,2,'2018-07-14',120.00),(6,3,'2018-07-15',15.00),(7,7,'2018-07-15',45.00),(8,8,'2018-07-15',65.00),(9,8,'2018-07-16',65.00),(10,9,'2018-07-16',48.00),(11,5,'2018-07-16',3500.00),(12,5,'2018-07-16',3500.00),(13,6,'2018-07-16',450.00);
/*!40000 ALTER TABLE `venda_produto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-04 18:05:31
