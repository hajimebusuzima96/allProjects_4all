import React from 'react';
import './style.css';

function Header() {
  return (
    <header>Trabalhando com componentes</header>
  );
}

export default Header;
