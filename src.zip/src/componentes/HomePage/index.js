import React from 'react';
import Card from '../Card/';
import './style.css';

export default function HomePage() {
  return (
    <div className="home-page">
      <Card />
      <Card />
      <Card />
    </div>
  );
}
