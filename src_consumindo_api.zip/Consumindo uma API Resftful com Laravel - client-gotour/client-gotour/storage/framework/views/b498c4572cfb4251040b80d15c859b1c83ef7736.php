<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        Novo Pacote
                    </div>
                    <div class="card-body">
                        <form method="POST" action="/pacote/cadastro" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group row">
                                <label for="nome" class="col-md-4 col-form-label text-md-right">Nome</label>

                                <div class="col-md-6">
                                    <input id="nome" type="text"
                                           class="form-control<?php echo e($errors->has('nome') ? ' is-invalid' : ''); ?>"
                                           name="nome" value="<?php echo e(old('nome')); ?>" required autofocus>

                                    <?php if($errors->has('nome')): ?>
                                        <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nome')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="valor" class="col-md-4 col-form-label text-md-right">Valor</label>
                                <div class="col-md-6">
                                    <input id="valor" type="text"
                                           class="form-control<?php echo e($errors->has('valor') ? ' is-invalid' : ''); ?>"
                                           name="valor" value="<?php echo e(old('valor')); ?>" required autofocus>

                                    <?php if($errors->has('valor')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('valor')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="dataInicio" class="col-md-4 col-form-label text-md-right">Data de
                                    Início</label>

                                <div class="col-md-6">
                                    <input id="dataInicio" type="date"
                                           class="form-control<?php echo e($errors->has('dataInicio') ? ' is-invalid' : ''); ?>"
                                           name="dataInicio" value="<?php echo e(old('dataInicio')); ?>" required autofocus>

                                    <?php if($errors->has('dataInicio')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('dataInicio')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="dataFim" class="col-md-4 col-form-label text-md-right">Data de Fim</label>

                                <div class="col-md-6">
                                    <input id="dataFim" type="date"
                                           class="form-control<?php echo e($errors->has('dataFim') ? ' is-invalid' : ''); ?>"
                                           name="dataFim" value="<?php echo e(old('dataFim')); ?>" required autofocus>

                                    <?php if($errors->has('dataFim')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('dataFim')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="telefone" class="col-md-4 col-form-label text-md-right">Telefone</label>

                                <div class="col-md-6">
                                    <input id="telefone" type="text"
                                           class="form-control<?php echo e($errors->has('telefone') ? ' is-invalid' : ''); ?>"
                                           name="telefone" value="<?php echo e(old('telefone')); ?>" required autofocus>

                                    <?php if($errors->has('telefone')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('telefone')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="site" class="col-md-4 col-form-label text-md-right">Site</label>

                                <div class="col-md-6">
                                    <input id="site" type="text"
                                           class="form-control<?php echo e($errors->has('site') ? ' is-invalid' : ''); ?>"
                                           name="site" value="<?php echo e(old('site')); ?>" required autofocus>

                                    <?php if($errors->has('site')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('site')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="urlImagem" class="col-md-4 col-form-label text-md-right">Imagem</label>

                                <div class="col-md-6">
                                    <input type="file" id="urlImagem"
                                           class="form-control<?php echo e($errors->has('urlImagem') ? ' is-invalid' : ''); ?>"
                                           name="urlImagem" value="<?php echo e(old('urlImagem')); ?>" autofocus>

                                    <?php if($errors->has('imagem')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('urlImagem')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="descricao" class="col-md-4 col-form-label text-md-right">Descrição</label>

                                <div class="col-md-6">
                                    <textarea id="descricao"
                                              class="form-control<?php echo e($errors->has('descricao') ? ' is-invalid' : ''); ?>"
                                              name="descricao" value="<?php echo e(old('descricao')); ?>" required
                                              autofocus></textarea>

                                    <?php if($errors->has('detalhes')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('detalhes')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary btn-sm">
                                        Enviar
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>