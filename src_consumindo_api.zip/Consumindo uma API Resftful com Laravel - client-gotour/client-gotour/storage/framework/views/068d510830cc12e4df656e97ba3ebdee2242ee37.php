<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="alert alert-danger">
                    <b>Tem certeza que deseja excluir o pacote abaixo?</b>
                </div>
                <div class="card">
                    <div class="card-header">Excluir Pacote</div>
                    <div class="card-body">
                        <form method="POST" action="/pacote/exclusao">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="id" value="<?php echo e($pacote['dados']['id']); ?>">
                            <div class="form-group row mb-0">
                                <table class="table table-striped">
                                    <thead>
                                    <th>ID</th>
                                    <th>Pacote</th>
                                    <th>Valor</th>
                                    <th>Data de início</th>
                                    <th>Data de Término</th>
                                    <th></th>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td><?php echo e($pacote['dados']['id']); ?></td>
                                        <td><?php echo e($pacote['dados']['pacote']['nome']); ?></td>
                                        <td>R$ <?php echo e($pacote['dados']['pacote']['valor']); ?></td>
                                        <td><?php echo e(date('d/m/Y',$pacote['dados']['pacote']['dataInicio'])); ?></td>
                                        <td><?php echo e(date('d/m/Y',$pacote['dados']['pacote']['dataFim'])); ?></td>
                                        <td>
                                            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-info btn-sm">voltar</a>
                                            <button type="submit" class="btn btn-danger btn-sm">Confirmar</button>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>