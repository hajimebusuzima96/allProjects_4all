<?php $__env->startSection('content'); ?>
    <div class="container">
        <img src="">

        <div class="row justify-content-center">
            <div class="col-md-12">
                <?php if(session('mensagem')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('mensagem')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-12">
                <?php if(session('erro')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('erro')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-12">
                <?php if($pacotes['status'] == 0): ?>
                    <div class="alert alert-danger">
                        <?php echo e($pacotes['erro']); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-12">
                <?php if($pacotes['status'] == 204): ?>
                    <div class="alert alert-info">
                        Não há pacotes cadastrados
                    </div>
                <?php elseif($pacotes['status'] == 200): ?>
                    <div class="card">
                        <div class="card-header">Listagem de Pacotes</div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <thead>
                                <th>ID</th>
                                <th>Pacote</th>
                                <th>Valor</th>
                                <th>Data de início</th>
                                <th>Data de Término</th>
                                <th></th>
                                <th></th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $pacotes['dados']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pacote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($pacote['id']); ?></td>
                                        <td><?php echo e($pacote['nome']); ?></td>
                                        <td>R$ <?php echo e($pacote['valor']); ?></td>
                                        <td><?php echo e(date('d/m/Y',$pacote['dataInicio'])); ?></td>
                                        <td><?php echo e(date('d/m/Y',$pacote['dataFim'])); ?></td>
                                        <td><a href="\pacote\edicao\<?php echo e($pacote['id']); ?>"
                                               class="btn btn-secondary btn-sm">Detalhes</a></td>
                                        <td><a href="\pacote\exclusao\<?php echo e($pacote['id']); ?>"
                                               class="btn btn-danger btn-sm">remover</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>