document.addEventListener('deviceready', function(){

	var request, db;
	window.indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;

	if(!window.indexedDB) 
	{
		navigator.notification.alert("Seu navegador não suporta o recurso HTML 5 IndexedDB",function(){},"Aviso","OK");
	}
	else 
	{
		request = window.indexedDB.open("DevMediaDB", 1);
		request.onerror = function(event)
		{
			navigator.notification.alert("Erro ao abrir o banco de dados: "+event,function(){},"Aviso","OK");
		}
	
		request.onupgradeneeded = function(event)
		{
			db = event.target.result;
			var objectStore = db.createObjectStore("lembretes", {keyPath: "id", autoIncrement : true });
		};
		
		request.onsuccess = function(event)
		{
			db = event.target.result;
			listarLembretes();
		}
	}
	
	$("#btn_add").on('click', function()
	{
		location.href = "cadastra-lembrete.html";
	});
	
	$("#btn_voltar").on('click', function()
	{
		location.href = "index.html";
	});
	
	$("#btn_criar").on('click', function()
	{
		criarLembrete();
	});
	
	$("#lembretes_area").on('click',function(e)
	{
		if($(e.target).attr("class")=="btn_apagar")
		{
			apagarLembrete($(e.target).attr("data-lembrete"));
		}
	});
	
	function criarLembrete()
	{	
		
		var input_lembrete = $("[name=lembrete]").val();
		var input_cor = $("[name=cor]").val();
		
		if(input_lembrete == "")
		{
			navigator.notification.alert("Campo lembrete obrigatório",function(){},"Aviso","OK");
			return false;
		}
		
		var transaction = db.transaction(["lembretes"],"readwrite");
		var objectStore = transaction.objectStore("lembretes");
		
		objectStore.add({lembrete: input_lembrete, cor: input_cor});
					
		transaction.oncomplete = function(event) 
		{	
			location.href = "index.html";
		};
					
		transaction.onerror = function(event) 
		{
			navigator.notification.alert("Erro ao criar lembrete: "+event,function(){},"Aviso","OK");
		};
	}
	
	function listarLembretes() 
	{
		var transaction = db.transaction(["lembretes"],"readwrite");
		var objectStore = transaction.objectStore("lembretes");

		objectStore.openCursor(null,"prev").onsuccess = function(event) 
		{
	    	var cursor = event.target.result;
	    	if(cursor) 
	    	{
	    	 	$("#lembretes_area").append("<div style='background:"+cursor.value.cor+"' class='lembrete'>"+cursor.value.lembrete+"<button class='btn_apagar' data-lembrete='"+cursor.value.id+"'>X</button></div>");
	      		cursor.continue();
	    	}  
	  	};
	}
	
	function apagarLembrete(idLembrete)
	{
		navigator.notification.confirm("Tem certeza que deseja apagar este lembrete ?",function(results)
		{
			if(results == 1)
			{
				var transaction = db.transaction(["lembretes"],"readwrite").objectStore("lembretes").delete(Number(idLembrete));
    
   				transaction.onsuccess = function(event)
        		{
        			$("[data-lembrete="+idLembrete+"]").parent().remove();
				};
				
				transaction.onerror = function(event) 
				{
					navigator.notification.alert("Erro ao tentar excluir",function(){},"Aviso","OK");
				};
			}
	    },
	    "Confirmação",
	    ['OK','Cancelar']);
	}
	
});