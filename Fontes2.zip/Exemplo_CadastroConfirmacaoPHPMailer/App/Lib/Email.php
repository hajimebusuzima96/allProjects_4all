<?php
	
	namespace App\Lib;
	
	class Email
	{
		public static function enviarEmailConfirmacaoCadastro($usuario, $hash)
		{
			self::enviar(
				$usuario->getEmail(),
				$usuario->getLogin(),
				'Confirmação de email',
				"<a>Clique <a href='http://" . APP_HOST . "usuario/ativacao/{$hash->getHash()}'>aqui</a>.</p>",
				"usuario/cadastrar/{$hash->getHash()} para ativar o seu cadastro.");
		}
		
		private static function enviar($para, $nome, $titulo, $html, $txt)
		{
			$mail = new \PHPMailer();
			$mail->isSMTP();
			$mail->Host = 'smtp.gmail.com';
			$mail->Port = 587;
			$mail->SMTPSecure = 'tls';
			$mail->SMTPAuth = true;
			$mail->Username = "mailcurso702@gmail.com";
			$mail->Password = "12tres45";
			$mail->setFrom('mailcurso702@gmail.com', 'Meu Nome');
			$mail->addReplyTo('replyto@meusite.com', 'Meu Nome');
			$mail->addAddress($para, $nome);
			$mail->Subject = $titulo;
			$mail->CharSet = 'UTF-8';
			$mail->msgHTML($html);
			$mail->AltBody = $txt;
			$mail->addAttachment(PATH . '/public/assets/logo-devmedia.png');
			
			if (!$mail->send()) {
				throw new \Exception("Erro no envio do e-mail: {$mail->ErrorInfo}");
			}
		}
	}