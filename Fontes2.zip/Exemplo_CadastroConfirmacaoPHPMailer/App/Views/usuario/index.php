<div class="container">
	<div class="jumbotron">
		<h1>Seja bem-vindo!</h1>
		
		<p>Agora você faz parte do time!</p>
		
		<p>
			<a class="btn btn-lg btn-primary" href="/" role="button">Voltar</a>
		</p>
	</div>
</div>
