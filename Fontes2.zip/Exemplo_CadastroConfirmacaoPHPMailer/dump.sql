CREATE TABLE `hash` (
  `id`            INT(11)      NOT NULL AUTO_INCREMENT,
  `hash`          VARCHAR(255) NOT NULL,
  `status`        INT(1)       NOT NULL,
  `id_usuario`    INT(11)      NOT NULL,
  `data_cadastro` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
)
  ENGINE = InnoDB
  AUTO_INCREMENT = 2
  DEFAULT CHARSET = utf8;

CREATE TABLE `usuario` (
  `id`            INT(11)      NOT NULL AUTO_INCREMENT,
  `email`         VARCHAR(100) NOT NULL,
  `login`         VARCHAR(20)  NOT NULL,
  `senha`         VARCHAR(50)  NOT NULL,
  `status`        INT(1)       NOT NULL,
  `data_cadastro` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `login` (`login`)
)
  ENGINE = InnoDB
  AUTO_INCREMENT = 2
  DEFAULT CHARSET = utf8;
