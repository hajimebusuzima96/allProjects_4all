﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FormularioAspNetMvc.Models
{
    public enum Sexo
    {
        Masculino,
        Feminino
    }
}