<?php 
include 'include/header.php';

echo "url original: contato.php";

include 'include/footer.php';
?>