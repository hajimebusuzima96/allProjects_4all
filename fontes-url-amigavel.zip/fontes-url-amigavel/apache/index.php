<?php 
include 'include/header.php';

echo "url original: index.php";

include 'include/footer.php';
?>