<?php include '../include/header.php'; ?>

<?php
echo "url original:  listar-produtos.php"; 
if (isset($_GET["nomecategoria"])) {
	echo "<br>nome da categoria: ". $_GET["nomecategoria"];
}
?>

<article>
	<section>
		<h2>Categorias</h2>
		<a href="/produtos/informatica/">Informatica</a>
		<a href="/produtos/mobilia/">Mobilia</a>
		<a href="/produtos/dep-geral/">Departamento geral</a>
	</section>

	<section>
		<h2>Produtos</h2>
		<a href="/produto/informatica/notebook/1">Notebook</a>
		<a href="/produto/informatica/kit-teclado-mouse/4">Kit teclado e mouse</a>
		<a href="/produto/mobilia/escrivaninha/2">Escrivaninha</a>
		<a href="/produto/dep-geral/cafe/3">Café</a>
	</section>
</article>

<?php include '../include/footer.php'; ?>