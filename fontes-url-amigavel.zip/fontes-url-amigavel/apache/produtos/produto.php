<?php 
include '../include/header.php';

echo "url original: produto.php";
if (isset($_GET["nomecategoria"]) && isset($_GET["idproduto"])) {
	echo "<br>nome da categoria: ". $_GET["nomecategoria"];
	echo "<br>id do produto: ". $_GET["idproduto"];
}

include '../include/footer.php';
?>