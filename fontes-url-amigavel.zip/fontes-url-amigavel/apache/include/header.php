<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Exemplo DevMedia</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="/exemplo/css/style.css">
</head>
<body>
	<header>
		<nav>
			<a href="/exemplo">Home</a>
			<a href="/exemplo/produtos/">Produtos</a>
			<a href="/exemplo/contato/">Contato</a>
		</nav>
	</header>
	<main>
		
