<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Exemplo DevMedia</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="/css/style.css">
</head>
<body>
	<header>
		<nav>
			<a href="/">Home</a>
			<a href="/produtos">Produtos</a>
			<a href="/contato">Contato</a>
		</nav>
	</header>
	<main>
		
