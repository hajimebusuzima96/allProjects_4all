import React from 'react';
import ListaDeSignos from './componentes/ListaDeSignos';

export default function App() {
  return (
    <ListaDeSignos />
  );
}
