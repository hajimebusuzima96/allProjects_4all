var app = angular.module("app", ["ngRoute"]);

app.controller('MainCtrl', ['$scope', function ($scope) {
  console.log(1);
  $scope.initMenu = function(){
    console.log(2); 
    if (typeof mCustomScrollbar != "undefined") {
      console.log(3);
      calcHeightItens();

      $("#nav-projeto").mCustomScrollbar({
        theme: "dark",
        scrollInertia: 600,
        axis: "y"
      });

      $(window).resize(function(){
        calcHeightItens();
        $("#nav-projeto").mCustomScrollbar("update");
      });
    }
  }
  $scope.initTop = function(){
    calcHeightItens();
    if (typeof mCustomScrollbar != "undefined") {
      $("#top-navbar").mCustomScrollbar({
        theme: "dark",
        scrollInertia: 600,
        axis: "x"
      });
  
      $(window).resize(function(){
        window.calcHeightItens();
        $("#top-navbar").mCustomScrollbar("update");
      });
    }
  }
}]);

app.controller('GlobalCtrl', function ($scope, $route, $location) {
  $("#nav-projeto .nav-itens .active").removeClass("active");
  $("#nav-projeto .nav-item a[href='#!"+$location.path()+"']").parent().addClass("active");

  if (typeof hljs != "undefined") {
		//hljs.initHighlightingOnLoad();
		//hljs.initLineNumbersOnLoad();

		$('pre code').each(function (i, block) {
			hljs.highlightBlock(block);
			if(!$(block).hasClass("nonumber")){
				hljs.lineNumbersBlock(block);
			}
		});
	}
});  

app.config(($routeProvider) => {
  $routeProvider
    .when("/", {
      templateUrl: "./view/ins-introducao.html",
      controller:"GlobalCtrl"
    })  
    .when("/ins-instalacao", {
          templateUrl: "./view/ins-instalacao.html",
          controller:"GlobalCtrl"
        })
    
    .when("/esc-primeiros-passos", {
      templateUrl: "./view/esc-primeiros-passos.html",
      controller:"GlobalCtrl"
    })
    .when("/esc-excecoes-e-erros", {
      templateUrl: "./view/esc-excecoes-e-erros.html",
      controller:"GlobalCtrl"
    })
    .when("/esc-provedores-de-dados", {
      templateUrl: "./view/esc-provedores-de-dados.html",
      controller:"GlobalCtrl"
    })
    .when("/esc-dependencias", {
      templateUrl: "./view/esc-dependencias.html",
      controller:"GlobalCtrl"
    })
    
    .when("/tes-ambiente", {
      templateUrl: "./view/tes-ambiente.html",
      controller:"GlobalCtrl"
    })
    .when("/tes-dubles-de-teste", {
      templateUrl: "./view/tes-dubles-de-teste.html",
      controller:"GlobalCtrl"
    })
    .when("/tes-testes-incompletos", {
      templateUrl: "./view/tes-testes-incompletos.html",
      controller:"GlobalCtrl"
    })
    .when("/ref-metodos-assert", {
      templateUrl: "./view/ref-metodos-assert.html",
      controller:"GlobalCtrl"
    })
    .when("/ref-anotacoes", {
      templateUrl: "./view/ref-anotacoes.html",
      controller:"GlobalCtrl"
    })
    .when("/ref-phpunit-xml", {
      templateUrl: "./view/ref-phpunit-xml.html",
      controller:"GlobalCtrl"
    })
    
    .when('/outro', { template: 'no outro' });
    //.otherwise({ redirectTo: './view/introducao.html' })
});

app.component('barraNavegacao', {
  templateUrl: './templates/navigationBar.html'
})

app.component('menuTopo', {
  templateUrl: './templates/menuTopo.html'
})

//angular.bootstrap(document, [ app.name ])