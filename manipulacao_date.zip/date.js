const dataUltimoAcesso = new Date('2020/11/11 17:00:00');
const dataAtual = new Date();

const hora = dataAtual.getHours();

const timeUltimoAcesso = dataUltimoAcesso.getTime();
const timeAtual = dataAtual.getTime();

const diferencaTime = timeAtual - timeUltimoAcesso;

const milissegundosHora = 1000 * 60 * 60;
const milissegundosDia = milissegundosHora * 24;

let msg = "";

if ( hora < 6 || hora >= 18 ) [curly_open]
  msg = 'Boa noite\n';
[curly_close] else if (hora >= 6  && hora < 12 ) [curly_open]
  msg = 'Bom dia\n';
[curly_close] else [curly_open]
  msg = 'Boa tarde\n';
[curly_close]

if ( diferencaTime > milissegundosDia ) [curly_open]
  msg += "Você está ausente há dias!!!";
[curly_close] else if (diferencaTime > milissegundosHora) [curly_open]
  msg += "Você está ausente há horas!!!";
[curly_close] else [curly_open]
  msg += "Que bom que ainda está aqui!";
[curly_close]

console.log(msg);