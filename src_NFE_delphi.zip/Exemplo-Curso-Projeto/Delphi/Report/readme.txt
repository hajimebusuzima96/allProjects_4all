Danfe.fr3 
---------
N�o deve ser mais usado, mantido para compatibilidade.


DanfeRetrato.fr3 
----------------
Oficial para quem usa o FastReport COMPLETO.
Contempla a maioria das propriedades do componente 


DanfeRetrato_Basic.fr3
----------------------
Deve ser utilizado por quem possui a vers�o do FastReport que acompanha o Delphi.
N�o aceita scripts dentro do relatorio


DANFeRetratoFS_Basic.fr3
------------------------
Para quem usa o Fast Report Basic que acompanha o Delphi e vai imprimir o Danfe em Formulario de Seguran�a
