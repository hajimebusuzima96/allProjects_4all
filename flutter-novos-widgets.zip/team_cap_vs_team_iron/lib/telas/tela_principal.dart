import 'package:flutter/material.dart';

class TelaPrincipal extends StatelessWidget {
  const TelaPrincipal({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(10),
        color: Colors.black,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "#TeamCap: Capitão América, Gavião Arqueiro, Falcão, Feiticeira, Buck, Homem Formiga",
              style: TextStyle(color: Colors.yellow, fontSize: 18),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 5),
            Container(
              height: 200,
              width: 360,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("img/team_cap.jpg")
                )
              )
            ),
            const SizedBox(height: 10),
            const Text(
              "Qual lado você vai escolher?",
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
            const SizedBox(height: 10),
            Container(
              height: 200,
              width: 360,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("img/team_iron.jpg")
                )
              )
            ),
            const SizedBox(height: 5),
            const Text(
              "#TeamIron: Pantera Negra, Visão, Homem Aranha, Homem de Ferro, Viúva Negra, Máquina de Combates",
              style: TextStyle(color: Colors.yellow, fontSize: 18),
              textAlign: TextAlign.justify,
            ),
          ],
        ),
      )
    );
  }
}