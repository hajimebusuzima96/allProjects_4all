import 'package:flutter/material.dart';

class TelaPrincipal extends StatelessWidget {
  const TelaPrincipal({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(30),
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage("img/background_xadrez.jpg"),
            fit: BoxFit.cover
          )
        ),
        child: Column(
          children: [
            const Text(
              "Dicas para ser invencível no xadrez",
              style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.star, color: Colors.yellow),
                Icon(Icons.star, color: Colors.yellow),
                Icon(Icons.star, color: Colors.yellow),
                Icon(Icons.star, color: Colors.yellow),
                Icon(Icons.star, color: Colors.yellow)
              ],
            ),
            const SizedBox(height: 15),
            const Text(
              "1 - Seja paciente",
              style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 5),
            const Text(
              "A pressa em um jogo de xadrez muitas vezes determina a derrota",
              style: TextStyle(fontSize: 16, color: Colors.yellow),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),
            const Text(
              "2 - Não perca suas torres",
              style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 5),
            const Text(
              "As torres são peças fundamentais em um jogo. Use-as com cuidado!",
              style: TextStyle(fontSize: 16, color: Colors.yellow),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),
            const Text(
              "3 - Entenda o valor das peças",
              style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 5),
            const Text(
              "É muito importante entender o quanto vale cada peça que você possui",
              style: TextStyle(fontSize: 16, color: Colors.yellow),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),
            const Text(
              "4 - Tenha táticas",
              style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 5),
            const Text(
              "Ter uma tática ajuda você a mover suas peças de forma inteligente no tabuleiro",
              style: TextStyle(fontSize: 16, color: Colors.yellow),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),
            const Text(
              "5 - Desenvolva seus bispos e cavalos",
              style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 5),
            const Text(
              "Peças de boa mobilidade que servem para ataque e defesa",
              style: TextStyle(fontSize: 16, color: Colors.yellow),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 20),
          ]
        ),
      )
    );
  }
}