import 'package:flutter/material.dart';

class TelaPrincipal extends StatelessWidget {
  const TelaPrincipal({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(30),
        decoration: BoxDecoration(
          image: const DecorationImage(
            image: AssetImage("img/background_saitama.jpg"),
            fit: BoxFit.cover,
          ),
          border: Border.all(
            width: 5,
            color: Colors.black
          )
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "O MESTRE SAITAMA",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            const Expanded(
              child: Text(
                "Com um poder aparentemente ilimitado, Saitama intriga a todos pela inexplicável força que possui. Ele é tão poderoso que nem mesmo ameaças como o Rei do Mar, Goketsu e Boros puderam pará-lo. Ele só precisa de um soco para acabar com as lutas. ",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
                textAlign: TextAlign.justify,
              ),
            ),
            const SizedBox(height: 10),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 160,
                  width: 320,
                  decoration: const BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage("img/soco_saitama.jpg"),
                      fit: BoxFit.contain,
                    )
                  ),
                ),
                const SizedBox(height: 5),
                const Text(
                  "Soco de Saitama = MORTE",
                  style: TextStyle(fontSize: 16, color: Colors.red, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.justify,
                )
              ],
            )
          ],
        ),
      )
    );
  }
}