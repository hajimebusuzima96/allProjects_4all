package br.com.devmedia.cursos.broadcastreceiver;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.Nullable;

public class MainActivity extends Activity {

    private BatteryBroadcastReceiver broadcast;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        broadcast = new BatteryBroadcastReceiver();

        registerReceiver(broadcast, new IntentFilter(Intent.ACTION_BATTERY_LOW));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcast);
    }
}
