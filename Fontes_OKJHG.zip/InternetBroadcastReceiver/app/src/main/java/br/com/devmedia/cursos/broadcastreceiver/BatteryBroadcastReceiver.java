package br.com.devmedia.cursos.broadcastreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class BatteryBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, String.format("Ação: %s", intent.getAction()),
                Toast.LENGTH_LONG).show();
    }
}
