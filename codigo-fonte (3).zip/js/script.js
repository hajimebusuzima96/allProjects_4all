$(document).ready(function(){
    $(".navbar-toggle").click(function(){
        $(".menu").toggleClass("menu-open");
    })
});