export interface Linguagem {
 _id: string;
 nome: string;
 urlImagem: string;
 numeroUsuarios: number;
 descricao: string;
 usuarioCurte: boolean;
}
