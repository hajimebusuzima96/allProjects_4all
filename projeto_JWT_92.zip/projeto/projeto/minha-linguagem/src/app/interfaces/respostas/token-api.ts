export interface TokenApi {
 token: string;
}
