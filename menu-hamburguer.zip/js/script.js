$(document).ready(function() {
	$("body").on('click', '.topo', function() {
		$("nav.menu").toggleClass("exibe_menu");
	});
});