package br.com.devmedia.wsjwt.webservice.exception;

public class UnauthorizedException extends RuntimeException {

    public UnauthorizedException(String s) {
        super(s);
    }

}
