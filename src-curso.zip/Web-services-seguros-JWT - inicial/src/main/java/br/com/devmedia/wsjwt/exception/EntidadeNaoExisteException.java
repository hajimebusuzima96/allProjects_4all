package br.com.devmedia.wsjwt.exception;

public class EntidadeNaoExisteException extends RuntimeException {

    public EntidadeNaoExisteException(String s) {
        super(s);
    }

}
