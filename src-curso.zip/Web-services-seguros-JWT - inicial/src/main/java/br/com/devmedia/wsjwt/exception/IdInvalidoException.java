package br.com.devmedia.wsjwt.exception;

public class IdInvalidoException extends RuntimeException {

    public IdInvalidoException(String s) {
        super(s);
    }

}
