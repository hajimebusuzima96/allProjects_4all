<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
      <div class="panel-heading">Remover o imóvel</div>
		<div class="panel-body">
			<form method="post" action="<?php echo e(route ('imoveis.destroy', $imovel->id)); ?>">
            <input type="hidden" name="_method" value="DELETE">
            <?php echo e(csrf_field()); ?>

				<div class="row">
					<div class="col-md-12">
						<h4>Tem certeza que deseja remover o imóvel?</h4>
						<hr>
						<h4>Sobre o imóvel</h4>
						<p>Descrição: <?php echo e($imovel->descricao); ?></p>
						<p>Preço: R$ <?php echo e(number_format($imovel->preco, 2, ',', '.')); ?></p>
						<p>Quantidade de Quartos: <?php echo e($imovel->qtdQuartos); ?></p>
						<p>Tipo: <?php echo e($imovel->tipo); ?></p>
						<p>Finalidade: <?php echo e($imovel->finalidade); ?></p>
						<hr>
						<h4>Endereço</h4>
						<p>Logradouro: <?php echo e($imovel->logradouroEndereco); ?></p>
						<p>Bairro: <?php echo e($imovel->bairroEndereco); ?></p>
						<p>Número: <?php echo e($imovel->numeroEndereco); ?></p>
						<p>CEP: <?php echo e($imovel->cepEndereco); ?></p>
						<p>Cidade: <?php echo e($imovel->cidadeEndereco); ?></p>
					</div>
				</div>
				<button type="submit" class="btn btn-danger">Remover</button>
				<a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Cancelar</a>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>