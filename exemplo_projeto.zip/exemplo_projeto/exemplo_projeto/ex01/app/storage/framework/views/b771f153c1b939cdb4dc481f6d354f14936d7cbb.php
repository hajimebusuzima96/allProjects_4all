<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">    
        <div class="panel-heading">Lista de Imóveis</div>
        <form method="GET" action="<?php echo e(route('imoveis.index', 'buscar' )); ?>">
        <div class="row">
        <div class="container" style="margin-top: 0.5em">
            <div class="col-md-12">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Digite o nome da cidade" name="buscar">
                    <span class="input-group-btn">
                        <button class="btn btn-default" type="submit">Pesquisar</button>
                    </span>
                </div>
            </div>
            </div>
        </div>
        </form>
        <div class="row">
        <div class="container" style="margin-top: 0.5em">
            <div class="col-md-12">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Descrição</th>
                            <th>Cidade</th>
                            <th>Preço</th>
                            <th>Finalidade</th>
                            <th>Tipo</th>
                            <th>Ações</th>
                        </tr>
                    </thead>            
                    <tbody>            
                        <?php $__currentLoopData = $imoveis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imovel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($imovel->descricao); ?></td>
                                <td><?php echo e($imovel->cidadeEndereco); ?></td>
                                <td><?php echo e($imovel->preco); ?></td>
                                <td><?php echo e($imovel->finalidade); ?></td>
                                <td><?php echo e($imovel->tipo); ?></td>
                                <td>
                                    <a href="<?php echo e(route('imoveis.edit', $imovel->id)); ?>"><i class="glyphicon glyphicon-pencil"></i></a>
                                    <a href="<?php echo e(route('imoveis.remove', $imovel->id)); ?>"><i class="glyphicon glyphicon-trash"></i></a>
                                    <a href="<?php echo e(route('imoveis.show', $imovel->id)); ?>"><i class="glyphicon glyphicon-zoom-in"></i></a>
                                </td>                                
                            </tr>                         
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                 
                    </tbody>
                </table> 
            </div> 
        </div>
        </div>
        <div align="center" class="row">
		    <?php echo e($imoveis->links()); ?>

	    </div>
    </div>
    <a href="<?php echo e(route('imoveis.create')); ?>"><button class="btn btn-primary">Adicionar</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('shared.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>