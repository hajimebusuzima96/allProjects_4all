<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pacote extends Model
{	
	protected $table = 'pacote';
	
	protected $fillable = [
		'nome','valor','datainicio','datafim','descricao','urlimagem','site','telefone'
	];

	protected $casts = [
		'datainicio' => 'Timestamp',
		'datafim' => 'Timestamp'
	];

	public $timestamps = false;
}
