package br.com.devmedia.java.cadastro.exception;

public class CadastroException extends RuntimeException {

    public CadastroException(String message) {
        super(message);
    }
}
