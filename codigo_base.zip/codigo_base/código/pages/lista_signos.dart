
import 'package:flutter/material.dart';

class ListaSignos extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text("Características dos Signos"),
        centerTitle: true,
      ),
      body: Container()

    );

  }
}



