    <footer class="footer">
        <div class="container">
            <p class="text-muted">
                Rodapé :)
            </p>
        </div>
    </footer>

    <script src="http://<?php echo APP_HOST; ?>/public/js/jquery-3.2.1.min.js"></script>
    <script src="http://<?php echo APP_HOST; ?>/public/js/jquery.validate.min.js"type="text/javascript"></script>
    <script src="http://<?php echo APP_HOST; ?>/public/js/bootstrap.min.js"></script>



    
</body>
</html>