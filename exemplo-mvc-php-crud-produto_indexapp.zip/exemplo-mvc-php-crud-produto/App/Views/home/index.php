<div class="container">
     <div class="starter-template">
            <h1><?php echo TITLE; ?></h1>
    </div>
</div>
