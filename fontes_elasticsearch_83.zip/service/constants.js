const DOCS_PAGE = 10;

module.exports = { DOCS_PAGE };
